# Phase 2: Claude Code Prompts (Mode A — First Setup)

These run inside **Claude Code Desktop** (no terminal `claude` CLI needed). **Windows users:** anything that shells out runs in the **WSL2 Ubuntu** shell, not PowerShell — see `references/os-detection.md`.

## Run as TWO PARALLEL SESSIONS

When you first open Claude Code, **open a second session/tab** and split the work:

| Session | Track | Prompts | You |
|---|---|---|---|
| **Session B** | **2b — autonomous** | the **2b kickoff** (covers Prompts 6, 8, 10) | paste it, then leave it — it installs the agent team, global skills, hooks, and schedules on its own |
| **Session A** | **2a — interactive** | **1 → 2 → 3 → 4 → 5 → 7**, then **Finalize** | run these yourself; you'll click through a couple of browser steps and watch the site go live |

**Why parallel:** 2b has no dependency on the live site, so it runs unattended while you drive 2a. The **one** join point is the agent-team dashboard — it needs both the live site *and* the installed agents, so it's built in the **2a Finalize step**, not in 2b.

**Order within Session A:** run prompts in sequence, waiting for each to finish. **Skip Prompt 6, 8, 9, 10 in Session A** — 6/8/10 belong to the 2b kickoff (Session B); 9 is folded into Finalize.

> **Zero-state rule (Session A / 2a):** 2a must not depend on the **global 8-agent install or routing rules** — those are 2b's job and may not exist yet. The one exception: Prompt 4 **writes its own local `developer.md` inline** (from `mac-mini-agents.md`) and uses it to build the first page — that's self-provisioned, so it's allowed. 2a writes that file into the **project** dir (`~/code-projects/{project-slug}/.claude/agents/`); 2b writes the full set into the **agents repo** + `~/.claude/agents/` — different locations, so the two sessions never fight over the same file.

> **Env collection — automate first (both tracks). [P8]** Wherever a step needs an API key, Claude tries to fetch it ITSELF — using the **Claude in Chrome extension (MCP)** or **computer-use** to open the relevant dashboard (Supabase, later Gemini/Resend) and copy the value, then writing it via `scripts/collect-credentials.py`. Claude asks you to do it manually **only when blocked** — login it can't pass, 2FA, CAPTCHA/Arkose, or billing/plan selection — naming the exact value and where to find it.

---

## Prompt 1 — Install tools + global permissions  ·  [2a — Session A]

```
Set up the machine tools and Claude Code configuration:

1. Install required tools (use the package manager for this OS — brew on macOS, apt in WSL2):
   brew install gh node jq ffmpeg          # macOS  (WSL2: sudo apt install -y gh nodejs jq ffmpeg)
   npm install -g vercel ccusage

   Verify:
   gh --version && node --version && jq --version && vercel --version
   # NOTE: do NOT install the Claude CLI or Resend here.
   #   • Claude runs in Desktop already — the CLI is an optional end-of-setup extra.
   #   • Resend is collected at feature-time (when the email feature is built), not now.

2. Authenticate GitHub CLI (skip if `gh auth status` already authenticated from Phase 1):
   gh auth status || gh auth login   # GitHub.com → HTTPS → Login with browser

3. Authenticate Vercel CLI:
   vercel login
   # → "Continue with GitHub" → browser → authorize → return to terminal
   vercel whoami

4. Create global directories:
   mkdir -p ~/.claude/agents ~/.claude/skills ~/.claude/rules

5. Run scripts/setup-permissions.py from this skill folder to write ~/.claude/settings.local.json
   (adds Bash(*), WebFetch, Skill(*), Supabase MCP permissions without overwriting existing content)

6. Print ~/.claude/settings.local.json to confirm.

7. Install usage hooks (token tracking + active hours):
   mkdir -p ~/.claude/hooks
   gh repo clone talentedgeai/infiniteleverage-8-agents-template /tmp/il-template --depth 1
   cp /tmp/il-template/hooks/usage-context.py ~/.claude/hooks/usage-context.py
   cp /tmp/il-template/hooks/update-project-status-usage.py ~/.claude/hooks/update-project-status-usage.py
   cp /tmp/il-template/hooks/session-start ~/.claude/hooks/session-start
   chmod +x ~/.claude/hooks/session-start
   rm -rf /tmp/il-template
   python3 ~/.claude/hooks/usage-context.py && echo "SessionStart hook OK"
   # update-project-status-usage.py is called by PM/Developer agents:
   # python3 ~/.claude/hooks/update-project-status-usage.py docs/project-status.html
```

---

## Prompt 2 — Global engineering rules  ·  [2a — Session A]
> **[Protocol 3]** The stack is Claude + GitHub + Vercel + Supabase. These rules enforce how that stack is used safely.

```
Write ~/.claude/rules/global-engineering.md with these exact contents:

# Global Engineering Rules

## Git
- Run `git status` before any file work.
- Never force-push to any branch.
- Never skip hooks with `--no-verify`.
- Never use `git add .` or `git add -A` — stage files explicitly by name.
- Never create a commit unless explicitly instructed.

## Branch and PR discipline
- Never push directly to `main` or `master`. All changes go through a pull request.
- Confirm the correct base branch before opening a PR.

## Deployment
- Never deploy using `vercel deploy` or `vercel --prod` directly.
- All deployments through `git push` → CI/CD only.

## Secrets
- Never commit `.env` files, API keys, tokens, or passwords.
- Never include secrets in code, comments, or commit messages.

## Environment variables
- Every project must have a `.env.example` at the repo root with all required and optional vars listed (empty values, one-line comments).
- Use `references/env-template.md` from the infiniteleverage-init skill as the starting template.
- If `.env.example` does not exist when starting implementation work, create it first.
- Every new env var introduced in code must be added to `.env.example` on the same commit.
- Optional vars (Stripe, Sentry) go commented out with a `#` prefix.

## Approvals
- Social posts → draft for approval first.
- Email campaigns → ALWAYS require human approval before sending.

## Destructive operations
- Always confirm with the user before: `rm -rf`, `git reset --hard`, dropping database tables.
```

---

## Prompt 3 — Supabase plugin (MCP)  ·  [2a — Session A]
> **[Protocol 7]** Supabase is the data layer — contact forms, subscribers, CRM. The Supabase connection comes from the **official Claude Code Supabase plugin** (`plugin:supabase`), not the standalone Supabase CLI. Installing a plugin and clicking through OAuth are steps Claude Code cannot do on its own — Claude will pause and walk you through them.

```
Connect this machine to Supabase using the official Claude Code Supabase plugin:
1. You cannot install a plugin for me — tell me to install it myself, then pause. I will run `/plugin` in Claude Code, open the marketplace, install "supabase", and restart the session if prompted. Wait until I confirm the plugin is installed.
2. Once I confirm the plugin is installed, start the Supabase authentication flow (mcp__supabase__authenticate) and give me the browser URL to authorize.
3. After I tell you I've authorized in the browser, finish the auth flow (mcp__supabase__complete_authentication).
4. Verify the connection by listing the Supabase projects on this account and confirming {project-slug} is present.
```

> **Manual steps (only you can do these — Claude will prompt you):**
> 1. Run `/plugin` in Claude Code → marketplace → install **supabase** → restart the session if prompted.
> 2. Open the auth URL Claude outputs → click **Authorize** → tell Claude "done".
>
> Note: The Supabase project was already created during Phase 1 account setup. Do NOT create a new project here.

---

## Prompt 4 — Project scaffold  ·  [2a — Session A]
> **[Protocol 4]** Agents are folders, not magic — every context file lives at an explicit path. **[Protocol 8]** The design system (`docs/brand/`) is written before any component ever gets built.

```
Create a project at ~/code-projects/{project-slug}/ that follows the Infinite Leverage folder structure:

mkdir -p ~/code-projects/{project-slug}
cd ~/code-projects/{project-slug}

mkdir -p agents/{product-manager,developer,qa,devops,writer,designer,web-publisher,email-marketer}/{context,skills}
mkdir -p content/{topics,content-calendar}
mkdir -p docs/architecture/{templates,workflows}
mkdir -p docs/{brand,engineering,product,qa,features,archive,plans}
mkdir -p docs/engineering/changes
mkdir -p docs/engineering/prompts
mkdir -p emails/drafts resources
mkdir -p standup/{individual,briefings}
mkdir -p working_files
mkdir -p .claude/{agents,skills,rules}

Scaffold Next.js 16 in the website/ subdirectory:
npx create-next-app@16 website \
  --typescript --tailwind --app --eslint \
  --src-dir --import-alias "@/*" \
  --agents-md --disable-git --yes

cd website && npx shadcn@latest init --defaults && cd ..

Write .gitignore at the project root covering: website/node_modules/, website/.next/, website/.env.local, working_files/, .env, .env.local, .env.*.local, .claude/settings.local.json, *.psd, *.ai, *.mov, *.mp4

Configure fonts in website/src/app/layout.tsx: Inter Tight (sans) + JetBrains Mono (mono) via next/font/google, CSS variables --font-inter-tight and --font-jetbrains-mono

Configure website/tailwind.config.ts with fontFamily.sans → var(--font-inter-tight) and fontFamily.mono → var(--font-jetbrains-mono)

Replace website/src/app/globals.css with Infinite Leverage design tokens:
@tailwind base; @tailwind components; @tailwind utilities;
:root {
  --ink: #0B1426; --ink-soft: #1F2A3D;
  --gray-1: #94A3B8; --gray-2: #64748B; --gray-3: #CBD5E1;
  --rule: #E2E8F0; --blue: #2563EB; --blue-soft: #DBEAFE;
  --cream: #F2EDE3; --paper: #FFFFFF;
}
body { @apply font-sans antialiased; color: var(--ink); background: var(--paper); }

Write ~/code-projects/{project-slug}/CLAUDE.md with: business name, stack (Next.js 16 App Router TypeScript), folder structure tree, Next.js 16 conventions (proxy.ts not middleware.ts, server components by default), engineering rules summary, content queue instructions, automated pipeline schedule.

Then inject the canonical Agent Delegation section so Claude knows how to auto-route requests to the 8 agents. Use the bundled script (single source of truth — never hand-write the table):

```bash
bash ~/.claude/skills/infiniteleverage-init/scripts/inject-agent-delegation.sh \
  ~/code-projects/{project-slug}/CLAUDE.md
```

Also inject it into the global ~/.claude/CLAUDE.md so machine-wide invocations route correctly:

```bash
bash ~/.claude/skills/infiniteleverage-init/scripts/inject-agent-delegation.sh \
  ~/.claude/CLAUDE.md
```

The script is idempotent — running it again refreshes the block between the BEGIN/END markers without touching surrounding content.

Research and document design system presets:
- WebSearch for: "best design systems for [business type] website 2024 typography palette"
- Document 5 distinct presets in docs/brand/style-guide.md
- Each preset must contain:
  name: (e.g. "Editorial", "Technical", "Warm", "Minimal", "Bold")
  use-case: one sentence on what content type or brand tone this suits
  typography: heading font + body font pair (Google Fonts preferred)
  palette: primary, secondary, background, text hex values
  spacing-scale: compact / balanced / generous
  tone: one adjective (e.g. authoritative, approachable, clean, energetic)
- Leave a blank line after each preset for the Designer to annotate which was used

Create the Developer agent definition now — this agent is needed before the others
to build the first personalized page:
Write .claude/agents/developer.md using the full Developer definition from
~/.claude/skills/infiniteleverage-init/references/mac-mini-agents.md

Invoke the Developer agent to build the hello-client landing page:
"Using the business name, tagline, and service description from CLAUDE.md and docs/product/overview.md
(if it exists) or from the credentials file, build a personalized landing page in website/src/app/page.tsx.
Apply the design tokens from globals.css and use the first design preset from docs/brand/style-guide.md.

The page must include all five sections in this exact order:

---

SECTION 1 — HERO
Full-width section. Content:
- Main heading: 'Hello, [ClientName].' (text-5xl font-bold tracking-tight)
- Subheading: one-line tagline from CLAUDE.md or credentials file
- Primary CTA button: label relevant to business type (e.g. 'Book a Session', 'Get Started', 'Let's Talk')
- Secondary link below the button: 'See how it works ↓' that smooth-scrolls to Section 3
Background: use the preset's primary color or a clean gradient. Text contrast must pass WCAG AA.

---

SECTION 2 — WHAT YOU GET (Infinite Leverage Agenda)
Section title: 'What You Get'
3-column card grid. Each card: icon (use a relevant emoji or Heroicons SVG), bold benefit headline,
one-sentence description. Research the business type and write real benefit copy — no placeholders.
Example for a coaching business: 'Clarity on your next move', 'A plan that runs without you',
'Content that builds your audience while you sleep'.

---

SECTION 3 — THE 18 PROTOCOLS (How It Works)
Section title: 'The 18 Protocols'
Section subtitle: 'The operating system behind every Infinite Leverage team.'

Render all 18 protocols grouped into exactly 5 tracks. Use the track names, protocol numbers,
and protocol text exactly as listed below — do not paraphrase or abbreviate:

Track 01 — Mindset
  P1:  Humans are the orchestrator. The real intelligence is still you.
  P2:  The CMS is dead. AI is the CMS.
  P3:  The stack: Claude, GitHub, Vercel, Supabase. Master four tools. Ship anything.
  P4:  Agents are folders, not magic. Structure beats novelty.

Track 02 — Infrastructure
  P5:  GitHub — version control for all code and context.
  P6:  Vercel — deploys only via git push. Never vercel deploy directly.
  P7:  Supabase — data, auth, and subscribers.

Track 03 — Building
  P8:  Design system written before any component ever gets built.
  P9:  Concrete step-by-step workflows that turn intent into output.
  P10: Communications go out automatically via scheduled PM runs.
  P11: Skills for admin so humans never have to escalate for small things.

Track 04 — Team and Ops
  P12: DevOps escalates to a human engineer when needed — never guesses on infrastructure.
  P13: 8 fixed agent roles. No improvising new ones.
  P14: PM plans every epic with acceptance criteria before a single line of code.
  P15: PM reads git history before every task — always knows what shipped yesterday.

Track 05 — Continuity
  P16: QA knows exactly what AI can and cannot test — and flags the rest to a human.
  P17: Context handed off via BRIDGE.md and the memory system — no knowledge tax between sessions.
  P18: Work outlives the operator — agents repo + sync-agents means any machine can be set up from GitHub.

Layout: one card per track. Inside each card: track number + track name as the card heading (monospace
label + bold title), followed by a numbered list of protocols. Use the design system's --blue accent
for protocol numbers and track labels. Cards in a 1-column stack on mobile, 2-column grid on md+,
single wide card for Track 01 to give it visual weight as the foundation track.

---

SECTION 4 — CONTACT FORM (unwired mockup, ready for integration)
Section title: 'Get in Touch'
Section subtitle: 'Ready to build your AI team? Let's talk.'

Form fields:
- Name (text input, required)
- Email (email input, required)
- Message (textarea, 4 rows, required)
- Submit button: 'Send Message'

Form state: on submit, show an inline 'Message sent — we'll be in touch soon.' success message.
The form must be built as a Server Action stub:
- Create website/src/app/actions/contact.ts with a `submitContact` Server Action that currently
  only returns { success: true } — add a TODO comment marking where Supabase insert + Resend email go.
- The form component uses useActionState (React 19) to handle pending/success/error states.
- No API route needed yet — the stub is wired to the Server Action, not a fetch call.
- Add data-testid attributes: 'contact-name', 'contact-email', 'contact-message', 'contact-submit',
  'contact-success' — QA will write Playwright tests against these.

---

SECTION 5 — FINAL CTA
Repeat the primary CTA button from Section 1 centered in a full-width dark background section.
Add one trust line below: e.g. 'Trusted by founders across Australia, Vietnam, and the US.' (adapt
to client's geography if known, otherwise use this default).

---

This is the Hello [ClientName] page — the first thing the client sees when the site goes live.
Make it feel real, not placeholder. No lorem ipsum anywhere."

Verify the dev server starts with the personalized page: cd website && npm run dev
Open http://localhost:3000, confirm the client name and branding appear, then Ctrl+C.
```

---

## Prompt 5 — Collect core credentials into .env.local (automated)  ·  [2a — Session A]

End of the deploy path — collect ONLY the keys the first deploy needs (**core/Supabase**). **Automate first, ask only when blocked.** Gemini/Resend stay deferred to feature-time.

```
Goal: write the CORE Supabase keys into ~/code-projects/{project-slug}/website/.env.local.
Confirm .env.local is gitignored first. Use the merge-safe collector (never clobbers existing values).

1. See what's missing:
   cd ~/code-projects/{project-slug}/website
   python3 ~/.claude/skills/infiniteleverage-init/scripts/collect-credentials.py --target .env.local --check core

2. For each missing key, GET IT YOURSELF before asking the user:
   - Use the Claude in Chrome extension (MCP) or computer-use to open the Supabase dashboard
     → project {project-slug} → Project Settings → API → copy:
        Project URL            → NEXT_PUBLIC_SUPABASE_URL
        publishable / anon key → NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY
        secret / service key   → SUPABASE_SECRET_KEY
   - Write each as you retrieve it:
       python3 ~/.claude/skills/infiniteleverage-init/scripts/collect-credentials.py --target .env.local \
         --set NEXT_PUBLIC_SUPABASE_URL=... NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=... SUPABASE_SECRET_KEY=...

3. Ask the user to fetch a value MANUALLY only if you genuinely can't — not logged in, 2FA,
   CAPTCHA, or the page won't load. Name the exact field and where it is. Don't ask for keys you
   were able to read yourself.

4. Also set NEXT_PUBLIC_SITE_URL=http://localhost:3000 for local dev.

DEFERRED — do NOT add now (collected the same automated way at feature-time):
  • GEMINI_API_KEY  → when image generation is built
  • RESEND_API_KEY / RESEND_FROM_EMAIL → when the email feature is built
  • LARK_* (optional) → all three or none, only if the client uses Lark

Re-run --check core; all three present → proceed to Prompt 7. Never commit .env.local.
```

> **Key names:** use the new Supabase naming (`NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`, `SUPABASE_SECRET_KEY`) per `references/env-template.md` — not legacy `ANON_KEY` / `SERVICE_ROLE_KEY`.

---

## ═══ 2b KICKOFF — paste this in Session B, then leave it running ═══

This launches the **autonomous** track. It has no dependency on the live site, so it runs unattended while you drive 2a in Session A.

```
You are running the Infinite Leverage "2b" autonomous setup track in this session, in parallel
with the interactive "2a" track running in another session. Do all of the following without
waiting on the other session, then report a completion summary. Do NOT build the agent-team
dashboard (it needs the live site — the 2a session builds it at its Finalize step).

Run these in order:
  1. Prompt 6  — install global skills
  2. Prompt 8  — fetch + write all 8 agent definitions
  3. Prompt 10 — install agents globally to ~/.claude/agents/ + install/wire hooks + register the 10 schedules

If a step needs an API key, collect it automatically (Claude in Chrome / computer-use) and only
ask the user if blocked. When finished, print: agent count in ~/.claude/agents/, the installed
skills, and the registered routine IDs — so the 2a Finalize step can verify you're done.
```

Prompts 6, 8, and 10 below are the bodies this kickoff runs. (In Session A, skip them.)

---

## Prompt 6 — Global skills  ·  [2b — Session B]

```
Install three global skills to ~/.claude/skills/:

Create ~/.claude/skills/daily-checkin/SKILL.md:
---
name: daily-checkin
description: This skill should be used when the user says "daily checkin", "morning standup", or "what's on today". Reads recent git commits, open PRs, and pending content briefs; outputs a plan for the day.
---
Steps: (1) git log --oneline -10 (2) gh pr list --state open (3) check content/topics/ for brief.md without blog.md (4) output: what shipped, open PRs, content queued

Create ~/.claude/skills/create-local-routine/SKILL.md:
---
name: create-local-routine
description: Create a persistent scheduled routine using mcp__scheduled-tasks — stored on disk in ~/.claude/scheduled-tasks/, local timezone, no expiry, no minimum interval. Runs while Claude Desktop is open; catches up on next launch if the app was closed.
---
Use mcp__scheduled-tasks__create_scheduled_task. Always load schema first via ToolSearch. Steps: (1) gather: routine ID (kebab-case), description, schedule (local time), prompt body (2) load schema (3) register via create_scheduled_task (4) confirm ID and storage path to user.

Create ~/.claude/skills/skill-creator/SKILL.md:
---
name: skill-creator
description: This skill should be used when the user says "create a skill", "new skill", "build a skill", or "add a skill". Guides creation of a new Claude Code skill folder following official conventions: lean SKILL.md with third-person triggers, progressive disclosure via references/ and scripts/.
---
Steps: (1) ask: skill name, trigger phrases, purpose (2) create skill-name/ directory under ~/.claude/skills/ (3) write SKILL.md with frontmatter name+description and imperative-form body (4) create references/ and scripts/ subdirectories if needed (5) confirm with ls
```

---

## Prompt 7 — Push to GitHub and connect Vercel  ·  [2a — Session A]
> **[Protocol 5]** GitHub is version control for all code and context. **[Protocol 6]** Vercel deploys only via `git push` — never `vercel deploy` directly.

```
Deploy the project:

1. Push to GitHub:
   cd ~/code-projects/{project-slug}
   git init && git checkout -b main
   git add CLAUDE.md .gitignore website/src/ website/public/ website/package.json website/package-lock.json website/tailwind.config.ts website/tsconfig.json website/next.config.ts
   git commit -m "init: {Business Name} — Infinite Leverage site"
   gh repo create {project-slug} --public --source=. --remote=origin --push

2. Tell me the GitHub repo URL — I need to import it to Vercel manually.
   Here are the exact steps:
   a. Go to vercel.com → click "Add New..." → "Project"
   b. Under "Import Git Repository", find {project-slug} and click "Import"
   c. Under "Configure Project", expand "Build and Output Settings"
   d. Find the "Root Directory" field → type: website
      (This tells Vercel your Next.js app is in the website/ folder, not the repo root)
   e. Click "Environment Variables" → add the CORE Supabase keys: NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY
   f. Click "Deploy" — wait for green checkmark
   Tell me "deployed" when Vercel shows the green success screen. 🎉 This is the Phase 2a win.

3. After I confirm the site is deployed:
   a. Link this local directory to the Vercel project:
      vercel link --project {project-slug} --yes

   b. Add the CORE secret env var via Vercel CLI:
      vercel env add SUPABASE_SECRET_KEY production
      # DEFERRED to feature-time (Phase 2b) — add only when that feature is built:
      #   vercel env add GEMINI_API_KEY production    # when image generation ships
      #   vercel env add RESEND_API_KEY production     # when email ships
      # Lark is optional — only run these if LARK credentials were provided:
      #   vercel env add LARK_APP_ID production
      #   vercel env add LARK_APP_SECRET production
      #   vercel env add LARK_WEBHOOK_URL production

   c. Verify deployment and show status:
      vercel ls
      vercel inspect https://{project-slug}.vercel.app
      curl -I https://{project-slug}.vercel.app
```

> **Manual step**: Open vercel.com/new → import `{project-slug}` → set **Root Directory = `website/`** → add `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY` → Deploy.
>
> All future deployments flow through `git push origin main` → GitHub → Vercel CI/CD. Never run `vercel deploy` or `vercel --prod` directly.

---

## Prompt 8 — Agent team: repo + definitions  ·  [2b — Session B]
> **[Protocol 1]** Agents act when asked — you are the orchestrator. **[Protocol 4]** Agents are folders with explicit context, not opaque magic. **[Protocol 13]** These 8 roles are fixed — don't improvise new ones.

```
⚠️ AGENTS REPO RULE — READ BEFORE DOING ANYTHING IN THIS PROMPT:
There must be exactly ONE agents repo per operator, ever. It is named `{clientslug}-agents`.
Multiple website/web-app projects may exist, but they all share this single agents repo.
Never create a second agents repo. Never create a per-project agents repo.

1. Check whether the agents repo already exists:
   gh repo view {clientslug}/{clientslug}-agents --json name 2>&1

   IF THE REPO ALREADY EXISTS:
   - Clone it locally if not already present: gh repo clone {clientslug}/{clientslug}-agents ~/{clientslug}-agents
   - cd ~/{clientslug}-agents && git checkout main && git pull origin main
   - Skip to step 3 (write agent definitions into the existing repo — do not reinitialise)
   - Do NOT run git init, do NOT run gh repo create

   IF THE REPO DOES NOT EXIST:
   - Proceed with steps 2 through 7 below to create it for the first time

2. Create the repo structure (first time only):
   mkdir -p ~/{clientslug}-agents/.claude/agents
   mkdir -p ~/{clientslug}-agents/agents/{product-manager,developer,qa,devops,writer,designer,web-publisher,email-marketer}/context
   mkdir -p ~/{clientslug}-agents/skills/sync-agents

   Write sync-agents/SKILL.md (triggers: "sync agents", "update agents", "pull latest agents")
   Steps: git pull origin main, cp -r .claude/agents/* ~/.claude/agents/, confirm with ls

3. Verify the source definitions file exists before proceeding:
   ls ~/.claude/skills/infiniteleverage-init/references/mac-mini-agents.md
   If not found, stop and report the missing file path — do not proceed.

   Write ALL 8 agent definition files to the agents repo's .claude/agents/ using the definitions in
   ~/.claude/skills/infiniteleverage-init/references/mac-mini-agents.md as the base.
   (This runs autonomously in the 2b session — do NOT assume the 2a session wrote anything.
   The 2a Prompt-4 developer.md lives in the PROJECT dir, a different location; write a fresh
   developer.md here in the agents repo too so 2b is fully self-contained.)

   Agents to write now (all 8): developer, product-manager, qa, devops, writer, designer, web-publisher, email-marketer

   Apply the updated rules across all agents:
   - Product Manager: Dan Shipper product thinking, hypothesis-based epics, user story format; auto-approve only high-priority + low-risk items after 2h; backlog everything else; all approval decisions written directly to project-status.html
   - QA: Dan Shipper tight-loop philosophy — QA is part of the development thread, not a gate; drafts QA plan from epic acceptance criteria before writing any test; writes QA-REPORT.md to the task's engineering doc folder; logs pass/fail to project-status.html; notifies Developer immediately after every run
   - Developer: obra/superpowers spec-first + TDD + Karpathy simplicity (already written in Prompt 4); follows engineering docs pattern for every task
   - DevOps: scoped strictly to GitHub CI/CD and Vercel CLI operations — no application code, no content
   - Writer: Neil Patel self-critique (hook, SEO, proof density, scanability, one CTA, cut 20%); validates brief.md has all required fields before writing
   - Designer: reads style-guide.md presets and selects best fit based on blog tone before generating
   - All agents: industry best practices principle (research top GitHub repos before acting)

   Engineering docs rule — embed this in the Developer and QA agent definitions:
   "## Engineering documentation (every task)
   Every task gets its own folder under docs/engineering/changes/:

   docs/engineering/changes/
   └── YYYY-MM/
       ├── YYYY-MM-DD-{task-slug}/
       │   ├── TECH-PLAN.md    ← Developer writes before any code
       │   ├── EXEC-PLAN.md    ← Developer checks off live during work
       │   ├── CHANGELOG.md    ← Developer writes once QA is green
       │   └── QA-REPORT.md    ← QA writes with AC coverage table + test results
       └── YYYY-MM-summary.md  ← one appended row per shipped task

   Developer: create the folder and write TECH-PLAN.md + EXEC-PLAN.md before touching any file.
   Write CHANGELOG.md and append to YYYY-MM-summary.md once QA returns PASS.
   QA: write QA-REPORT.md to the same folder. Never skip this — work is not done until all 4 files exist."

   Universal wave rule — embed this in EVERY agent definition:
   "## QA Round (every wave)
   After completing your primary deliverable in any wave, call @qa with:
   '@qa Review my output from this wave only: [describe what you just built/wrote/changed].
   Check for correctness, edge cases, and quality issues. Return pass/fail with specific findings.'
   Wait for @qa response. If @qa returns FAIL, fix the flagged issues before declaring the wave done.
   If @qa returns PASS, proceed. Never skip the QA round to save time."

3b. Write the domain-setup skill for the Developer agent:
    Path: ~/{clientslug}-agents/agents/developer/context/skills/domain-setup/SKILL.md
    Also install it globally: ~/.claude/skills/domain-setup/SKILL.md (copy same file)

    The SKILL.md content must be:

    ---
    name: domain-setup
    description: This skill should be used when the operator says "set up a new domain", "add a new client domain", "onboard a new operator account", "create operator email", or "connect domain to Google Workspace". Guides the full Google Workspace secondary domain + DNS + Vercel + service account setup for a new operator.
    ---

    # Domain Setup — New Operator Account

    ## Purpose
    Set up a professional operator email under a client's own domain, fully connected to GitHub, Vercel, and Supabase. Uses the infinite-8.com Google Workspace as the master account.

    ## Steps

    ### 1. Add Secondary Domain in Google Workspace
    - Log into the master infinite-8.com Google Workspace Admin Console (Admin → Add a domain → Add as secondary domain)
    - Enter the new operator domain (e.g. `clientname.com`)
    - Google will provide a TXT record for DNS verification — copy it

    ### 2. Add TXT Record in Vercel DNS
    - Go to Vercel → Domains → find the client domain → DNS tab
    - Add the TXT record Google provided
    - Return to Google Admin Console and click Verify

    ### 3. QA Verification — DNS propagation
    After TXT record is added and Google confirms verification:
    Invoke @qa: "Verify DNS setup for {domain}: confirm the Google TXT record resolves via `dig TXT {domain}`,
    confirm MX records are active via `dig MX {domain}`, and confirm the domain shows as verified
    in Google Admin Console. Log pass/fail to docs/project-status.html under Infrastructure → Domain Setup."

    Wait for @qa confirmation before proceeding to Step 4.

    ### 4. Set MX Records via Vercel
    - In Vercel DNS for the domain, use the "Set MX records for Google" option (handles Google Workspace mail routing automatically)
    - No manual MX record entry needed

    ### 5. Create Operator Email
    - In Google Admin Console → Users → Add new user
    - Create: `{firstname}@{clientdomain}.com`
    - Save the temporary password to the credentials file

    ### 6. Set Up Service Accounts
    Using the new operator email, create accounts at:
    - GitHub (github.com/signup) — verify email
    - Vercel (vercel.com/signup) — link to GitHub via OAuth
    - Supabase (supabase.com) — create new organisation

    ### 7. Update project-status.html
    Open docs/project-status.html and add or update the Infrastructure table row for Domain Setup:

    | Section | Field | Value |
    |---------|-------|-------|
    | Infrastructure → Domain Setup | Domain | {clientdomain}.com |
    | | Operator email | {firstname}@{clientdomain}.com |
    | | Services connected | GitHub ✅ / Vercel ✅ / Supabase ✅ |
    | | DNS verified | ✅ TXT + MX confirmed by @qa |
    | | Status | ✅ Complete — {YYYY-MM-DD} |

    If project-status.html does not yet exist, create it with a minimal HTML shell containing an Infrastructure section table.

    ## Edge Cases
    - **Domain already in Google Workspace**: skip step 1, go straight to TXT verification
    - **DNS not propagated within 10 min**: note in project-status.html as ⏳ Pending, continue with other steps, return to verify
    - **Existing SPF record on domain**: add `include:amazonses.com` to the existing record — do not replace it
    - **@qa not available**: log DNS check manually using `dig` in terminal and paste results to project-status.html

4. Write default-persona.md for all 8 agents at agents/{agent}/context/default-persona.md

5. Write email sequence index at agents/email-marketer/context/email-index.md
   Include Stage 0 welcome email template with clear {placeholder} markers

6. Write README.md describing the 8-agent team, install instructions, sync workflow

7. Push repo to GitHub (first time only — skip if repo already existed in step 1):
   cd ~/{clientslug}-agents
   git init && git checkout -b main
   git add .
   git commit -m "init: 8-agent team — Build + GTM"
   gh repo create {clientslug}/{clientslug}-agents --public --source=. --remote=origin --push

   If repo already existed, just commit and push the updated agent definitions:
   cd ~/{clientslug}-agents
   git add .
   git commit -m "update: agent definitions for {project-slug}"
   git push origin main
```

---

## Prompt 9 — 2a FINALIZE / JOIN: verify 2b, build dashboard, write HANDOFF  ·  [2a — Session A, after HTTP 200]

This is the **single join point** between the two parallel tracks. Run it in Session A **only after the site returns HTTP 200** (Prompt 7). It first confirms the autonomous 2b track actually finished, then builds the dashboard (which needs both the live site and the installed agents) and writes the handoff.

```
FINALIZE — run after the site is live (HTTP 200).

1. Verify the 2b autonomous track completed:
   - ls ~/.claude/agents/*.md | wc -l        # expect 8
   - confirm the 10 routines are registered (https://claude.ai/code/routines or the 2b summary)
   - confirm global skills exist: ls ~/.claude/skills/{daily-checkin,create-local-routine,create-remote-routine}
   If anything is missing, finish it here (re-run the relevant part of Prompt 6/8/10) before continuing.
   Report what you found and fixed.

2. Then build the agent team dashboard (needs the live site + the 8 agents):
```

```
Generate an HTML file at ~/{clientslug}-agents/team-dashboard.html that gives the client
a beautiful, at-a-glance overview of their AI team. Commit it to the agents repo when done.

The file must be fully self-contained (no external CSS files, no CDN fonts except Google Fonts).

--- DESIGN SYSTEM ---
Font: Inter from Google Fonts (weights 400, 500, 600)
Base font size: 16px. Never go below 14px anywhere on the page.
Line height: 1.6
Color palette:
  --ink: #0B1426        (headings, body text)
  --ink-soft: #1F2A3D   (secondary text)
  --gray-1: #94A3B8     (muted labels)
  --rule: #E2E8F0       (borders, dividers)
  --blue: #2563EB       (accent, links, badges)
  --blue-soft: #DBEAFE  (badge backgrounds, highlights)
  --cream: #F2EDE3      (section backgrounds)
  --paper: #FFFFFF      (card backgrounds)
Background: #F8FAFC (page level)
Cards: white, border-radius 12px, box-shadow 0 1px 3px rgba(0,0,0,0.08)
Spacing: generous padding (24px inside cards, 32px between sections)

--- SECTION 1: AGENT CARDS (one card per agent, 2-column grid) ---
For each of the 8 agents, render a card with:
  • Agent name (large, 20px, 600 weight) + role badge (blue-soft background)
  • Role: one-sentence description of what this agent owns
  • Tasks: bullet list of 3–5 core recurring tasks
  • Inputs: what triggers or feeds this agent (files, human prompts, schedules)
  • Outputs: what it produces (files, messages, PRs, emails)
Use the 8 agent definitions from .claude/agents/ as the source of truth.

--- SECTION 2: WEEKLY CALENDAR ---
Render a 5-column table (Mon–Fri). Each cell shows scheduled agent runs for that day.
Use the schedule from Prompt 10 (RemoteTrigger registrations) as source:
  Mon 9am — Writer
  Tue 9am — Designer
  Wed 9am — Web Publisher
  Thu 10am — Email Marketer
  Fri 5pm — PM: Weekly RAG report
  Weekdays 7am — PM: Daily plan
  Weekdays 6pm — PM: Standup compile
  Weekdays 6:30pm — PM: EOD summary
Style each entry as a small pill: agent name + time, colored by agent type.

--- SECTION 3: CROSS-AGENT FLOW DIAGRAM ---
Render an inline SVG flow diagram (no Mermaid, no external JS) showing how agents hand off
to each other in the content pipeline:
  Writer → Designer → Web Publisher → (live on site)
  PM → orchestrates all agents → reports to Human
  Developer ← PM (epic) → QA (tests) → DevOps (deploy)
  Email Marketer ← PM (schedule)
Keep it clean: rounded rectangles, directional arrows, agent name + icon emoji inside each node.
Use --blue for arrows, --ink for node borders, --blue-soft for node fills.
Nodes must be large enough to read comfortably (min 120×48px).

--- FOOTER ---
Generated date, project name, live URL (https://{project-slug}.vercel.app), agents repo URL.

After generating:
  cd ~/{clientslug}-agents
  git add team-dashboard.html
  git commit -m "docs: add agent team dashboard"
  git push origin main

Open team-dashboard.html in the browser and confirm it renders correctly.
Tell me: "Dashboard ready — open ~/{clientslug}-agents/team-dashboard.html"
```

```
3. Confirm production health, then write HANDOFF.md (this is the last step):
   curl -I https://{project-slug}.vercel.app          # HTTP 200
   vercel ls                                          # recent deployments + status
   vercel env ls production                           # core env vars present

   Write HANDOFF.md at ~/{clientslug}-agents/HANDOFF.md
   # [Protocol 17] Context handoff — how the client picks up without Dave present
   # [Protocol 18] Work outlives the operator — agents repo + sync means any machine rebuilds from GitHub
   Include: all 8 agents with trigger phrases, content pipeline schedule, sync instructions,
   live URL, repo URL, the first-actions guide, and the 10 routine IDs from ~/.claude/.il-2b-routines.txt.
   Manage routines at: https://claude.ai/code/routines
```

Setup complete — proceed to **Phase 3** in the SKILL (stamp version + register plugin).

---

## Prompt 10 — Install agents globally + register schedules  ·  [2b — Session B]

```
1. Install all 8 agents and skills globally:
   cp -r ~/{clientslug}-agents/.claude/agents/* ~/.claude/agents/
   cp -R ~/{clientslug}-agents/.claude/skills/. ~/.claude/skills/
   mkdir -p ~/.claude/scheduled-tasks
   cp -R ~/{clientslug}-agents/.claude/scheduled-tasks/. ~/.claude/scheduled-tasks/
   ls ~/.claude/agents/           # confirm all 8 present
   ls ~/.claude/scheduled-tasks/  # confirm all 8 task folders present

2. Update ~/.claude/CLAUDE.md with agents repo pointer:
   ## Agents repo
   https://github.com/{clientslug}/{clientslug}-agents
   Local: ~/{clientslug}-agents/
   Update: say "sync agents" in Claude Code

3. Register 10 cloud RemoteTrigger routines:
   # [Protocol 10] These run in Anthropic's cloud (CCR) — Mac Mini does not need to be awake.
   # [Protocol 2] Web Publisher is the CMS — no manual page editing after this.
   #
   # IMPORTANT: Load RemoteTrigger schema first: ToolSearch(query: "select:RemoteTrigger")
   # Read the prompt body from ~/.claude/scheduled-tasks/{name}/SKILL.md for each task.
   # Cron expressions are in UTC. Client timezone is Asia/Saigon (UTC+7).
   # environment_id for all routines: env_01Ly7cgFD1z5N2xN9VtNZ42S

   For each task below, call RemoteTrigger(action: "create", body: { name, cron_expression, job_config }):

   devops-daily         → cron_expression: "3 23 * * 0-4"   (weekdays 6:03 AM Asia/Saigon — production health + CI/CD → epic-status.md)
   pm-daily-plan        → cron_expression: "3 0 * * 1-5"    (weekdays 7:03 AM Asia/Saigon — reads epic-status.md, updates project-status.html)
   developer-daily      → cron_expression: "3 2 * * 1-5"    (weekdays 9:03 AM Asia/Saigon — picks up approved items, runs dev-tdd loop)
   pm-standup-compile   → cron_expression: "7 11 * * 1-5"   (weekdays 6:07 PM Asia/Saigon)
   pm-eod-summary       → cron_expression: "37 11 * * 1-5"  (weekdays 6:37 PM Asia/Saigon)
   pm-weekly-rag        → cron_expression: "7 10 * * 5"     (Fridays 5:07 PM Asia/Saigon)
   writer-weekly        → cron_expression: "3 2 * * 1"      (Mondays 9:03 AM Asia/Saigon)
   designer-weekly      → cron_expression: "3 2 * * 2"      (Tuesdays 9:03 AM Asia/Saigon)
   web-publisher-weekly → cron_expression: "3 2 * * 3"      (Wednesdays 9:03 AM Asia/Saigon)
   email-marketer-weekly → cron_expression: "3 3 * * 4"     (Thursdays 10:03 AM Asia/Saigon)

   Save all 10 routine IDs to ~/.claude/.il-2b-routines.txt (one "name: id" per line) so the
   2a Finalize step can fold them into HANDOFF.md. Routines are persistent — no expiry, no
   re-registration needed. Manage at: https://claude.ai/code/routines

4. Verify the autonomous track (NO live-site checks — those belong to the 2a Finalize step):
   ls ~/.claude/agents/           # all 8 present
   ls ~/.claude/scheduled-tasks/  # all 8 task folders present
   gh repo view {clientslug}-agents

5. Report completion so the 2a session can verify:
   Print the agent count, the installed global skills, and the 10 routine IDs.
   # HANDOFF.md is written by the 2a Finalize step (Prompt 9) — it has the live URL. Do not write it here.
```
